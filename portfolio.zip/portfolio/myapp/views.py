from django.shortcuts import render

# Create your views here.
def base(request):
    return render(request,'Base.html')

def home(request):
    return render(request,'home.html')

def project(request):
    return render(request,'projects.html')

def about_view(request):
    return render(request,'about.html')

def certificate_view(request):
    return render(request,'certification.html')

def contact(request):
    return render(request,'contact.html')